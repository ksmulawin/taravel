<?php $__env->startSection('content'); ?>
	<div class="col-md-6 offset-md-3">
		<form method="post" action="<?php echo e(url('edit-bucket')); ?>">
			<?php echo e(csrf_field()); ?>

			<div class="card">
			  <div class="card-header">
					Edit Destination
			  </div>
			  <div class="card-body">
				<div class="form-group">
					<label for="destination">Destination</label>
					<input type="text" name="destination" value="<?php echo e($bucket->destination); ?>" id="destination" class="form-control">
				</div>
				<div class="form-group">
					<label for="details">Details</label>
					<textarea name="details" id="details" class="form-control"><?php echo e($bucket->details); ?></textarea>
				</div>
			  </div>
			  <input type="hidden" name="bucket_id" value="<?php echo e($bucket->id); ?>">
			  <div class="modal-footer">
				<button type="submit" class="btn btn-primary">Save changes</button>
				<a href="<?php echo e(route('bucket')); ?>" class="btn btn-secondary" data-dismiss="modal">Close</a>

		</form>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>