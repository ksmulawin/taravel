<?php $__env->startSection('content'); ?>
	<div class="col-md-6 offset-md-3">
		<form method="post" action="<?php echo e(url('update-schedule')); ?>">
			<?php echo e(csrf_field()); ?>

			<div class="card">
			  <div class="card-header">
					Edit Schedule
			  </div>
			  <div class="card-body">
					<div class="form-group">
						<label for="destination">Destination</label>
						<input type="text" list="destination_option" name="destination" value="<?php echo e($sched->destination); ?>" id="destination" class="form-control">
						<datalist id="destination_option">


						</datalist>
					</div>
					<div class="form-group">
						<label for="details">Details</label>
						<textarea name="details" id="details" class="form-control"><?php echo e($sched->details); ?></textarea>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-6">
								<label for="checkin">Check In</label>
								<input type="datetime-local" class="form-control" name="checkin" id="checkin" value="<?php echo e(($sched->planned_date)->format('m-d-Y h:i a')); ?>">
							</div>
							<div class="col-md-6">
								<label for="checkout">Check Out</label>
								<input type="datetime-local" class="form-control" name="checkout" id="checkin" value="<?php echo e(($sched->planned_date)->format('m-d-Y h:i a')); ?>">
							</div>
						</div>
					</div>
			  </div>
			  <input type="hidden" name="schedule_id" value="<?php echo e($sched->id); ?>">
			  <div class="modal-footer">
				<button type="submit" class="btn btn-primary">Save changes</button>
				<a href="<?php echo e(route('schedule')); ?>" class="btn btn-secondary" data-dismiss="modal">Close</a>

		</form>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>